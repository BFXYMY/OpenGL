==========================================================================
       OpenGL Lesson 22:  Bump Mapping, Multi-Texturing & Extensions
==========================================================================

  Authors Name: Jens Schneider

  Disclaimer:

  This program may crash your system or run poorly depending on your
  hardware.  The program and code contained in this archive was scanned
  for virii and has passed all test before it was put online.  If you
  use this code in project of your own, send a shout out to the author!

==========================================================================
                        NeHe Productions 1997-2004
==========================================================================
